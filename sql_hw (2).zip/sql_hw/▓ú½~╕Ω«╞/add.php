<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>add.php</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["Insert"])) {
   $sql_1 = "SELECT MAX(產品編號) AS max_product_no FROM 產品資料";
   $result = mysqli_query($link, $sql_1);
   $row = mysqli_fetch_assoc($result);
   $maxProductNo = $row['max_product_no'];
   //$maxProductNo++;
   //$newProductNo=$maxProductNo;
   $newProductNo = $maxProductNo + 1;
   $drink=$_POST["drink"];
   $price=$_POST["price"];
   $cost=$_POST["cost"];
   $inventory=$_POST["inventory"];
   $safetystock=$_POST["safetystock"];

   $pd_class_no="";
   if (strpos($drink, "汁") !== false) 
      $pd_class_no = "1";
   if (strpos($drink, "奶") !== false){
      $pd_class_no = "4";
   }else if(strpos($drink, "茶類") !== false) 
      $pd_class_no = "2";
   if (strpos($drink, "水") !== false) 
      $pd_class_no = "6";
   if (strpos($drink, "酒") !== false) 
      $pd_class_no = "7";
   if (strpos($drink, "運動") !== false) 
      $pd_class_no = "5";
   if (strpos($drink, "咖啡") !== false) 
      $pd_class_no = "8";

   $c_sql = "SELECT 供應商編號 FROM 供應商 ORDER BY RAND() LIMIT 1";
   $c_result = mysqli_query($link, $c_sql);
   $c_row = mysqli_fetch_assoc($c_result);
   $clientno = $c_row['供應商編號'];

   $in = "INSERT INTO 產品資料 (產品編號,類別編號,供應商編號,產品名稱,建議單價,平均成本,庫存量,安全存量) VALUES (";
    $in .= "'" . $newProductNo . "','" . $pd_class_no . "','";
    $in .= $clientno . "','" . $drink . "','" . $price . "','" . $cost . "','";
    $in .= $inventory . "','" . $safetystock . "')";

   mysqli_query($link, 'SET NAMES utf8');

   if ( mysqli_query($link, $in) )
      echo "資料新增成功<br/>";
   else
      die("資料新增失敗<br/>");
}
?>
<form action="add.php" method="post">
<table>
<h2>新增產品資料</h2>
<tr><td>產品名稱:</td>
   <td><select name="drink">
      <option value="蘋果汁" selected="False">蘋果汁	</option>
      <option value="蔬果汁">蔬果汁	</option>
      <option value="汽水">汽水	</option>
      <option value="蘆筍汁">蘆筍汁	</option>
      <option value="運動飲料">	運動飲料	</option>
      <option value="牛奶">牛奶	</option>
      <option value="礦泉水">礦泉水	</option>
      <option value="咖啡">咖啡	</option>
      <option value="奶茶">奶茶	</option>
      <option value="啤酒">啤酒	</option>
   </td>
</tr><tr><td>建議單價:</td>
   <td><input type="text" name="price" size="10"/></td>
</tr><tr><td>平均成本:</td>
   <td><input type="text" name="cost" size="10"/>
</tr><tr><td>庫存量:</td>
   <td><input type="text" name="inventory" size="10"/></td>
</tr><tr><td>安全存量:</td>
   <td><input type="text" name="safetystock" size="10"/></td>
</tr>
</table>
<p>
<input type="submit" name="Insert" value="新增"/><hr>
<p>&nbsp</p>
</form>
<form method="post" action="product_information.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>