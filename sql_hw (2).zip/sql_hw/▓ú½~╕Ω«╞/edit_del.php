<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>revise.php</title>
</head>
<body>
<?php
require_once("open.inc");
$id = $_GET["id"];
$action = $_GET["action"];
switch ($action) {
   case "update": 
      $drink=$_POST["drink"];
      $price=$_POST["price"];
      $cost=$_POST["cost"];
      $inventory=$_POST["inventory"];
      $safetystock=$_POST["safetystock"];
      $sql = "UPDATE 產品資料 SET 產品名稱=
      '".$drink."', 建議單價='".$price."', 平均成本='".$cost."', 
      庫存量='".$inventory."', 安全存量='".$safetystock."'
      WHERE 產品編號='".$id."'";
      mysqli_query($link, $sql);  
      echo "修改完成!";
      break;
   case "del": 
      $sql_del = "SELECT 產品編號 FROM 產品資料 WHERE 產品編號='".$id."'";
      $result_del = mysqli_query($link, $sql_del);
      $row_del = mysqli_fetch_assoc($result_del);
      $deleted_id = $row_del['產品編號'];
      $sql = "DELETE FROM 產品資料 WHERE 產品編號='".$id."'";
      mysqli_query($link, $sql);
      echo "成功刪除資料!";
      $update_sql = "UPDATE 產品資料 SET 產品編號 = 產品編號 - 1 WHERE 產品編號 > '$deleted_id'";
      mysqli_query($link, $update_sql);
      break;
   case "edit":
      $sql = "SELECT*FROM 產品資料 WHERE 產品編號='".$id."'";
      $result = mysqli_query($link, $sql); 
      $row = mysqli_fetch_assoc($result);
      $drink=$row["產品名稱"];
      $price=$row["建議單價"];
      $cost=$row["平均成本"];
      $inventory=$row["庫存量"];
      $safetystock=$row["安全存量"];
?>
<form action="edit_del.php?action=update&id=<?php echo $id ?>"method="post">
<table border="1">
<tr><td><font size="2">產品名稱: </font></td>
   <td><input type="text" name="drink" size="25"
   maxlength="10" value="<?php echo $drink ?>"/></td></tr>
<tr><td><font size="2">建議單價: </font></td>
    <td><input type="text" name="price" size="10"
    maxlength="10" value="<?php echo $price ?>"/></td></tr>
<tr><td><font size="2">平均成本: </font></td>
   <td><input type="text" name="cost" size="10"
    maxlength="10" value="<?php echo $cost ?>"/></td></tr>
<tr><td><font size="2">庫存量: </font></td>
   <td><input type="text" name="inventory" size="25"
   maxlength="10" value="<?php echo $inventory ?>"/></td></tr>
<tr><td><font size="2">安全存量: </font></td>
   <td><input type="text" name="safetystock" size="25"
   maxlength="10" value="<?php echo $safetystock ?>"/></td></tr>

<tr><td><input type="submit"  value="更新產品資料"/></td></tr>
</table>
</form>
<?php   
       break;
} 
?>

<form method="post" action="product_information.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>