<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>revise.php</title>
</head>
<body>
<?php
require_once("open.inc");
$id = $_GET["id"];
$action = $_GET["action"];
switch ($action) {
   case "update": 
      $drink=$_POST["drink"];
      $price=$_POST["price"];
      $count=$_POST["count"];
   
      $pdno_sql = "SELECT 產品編號 FROM 產品資料 WHERE 產品名稱 = '$drink'";
      $result = mysqli_query($link, $pdno_sql);
      $row = mysqli_fetch_assoc($result);
      $pd_no = $row["產品編號"];

      $sql = "UPDATE 訂單明細 SET 產品編號='$pd_no', 實際單價='$price', 數量='$count' WHERE 訂單編號='$id'";
      mysqli_query($link, $sql); 
      echo "修改完成!";
      break;
   case "del": 
      $sql = "DELETE FROM 訂單明細 WHERE 訂單編號='".$id."'";
      mysqli_query($link, $sql);
      echo "成功刪除資料!";
      break;
   case "edit":
      $sql = "SELECT 訂單明細.訂單編號,訂單明細.產品編號,產品資料.產品名稱,訂單明細.實際單價,訂單明細.數量
      FROM 訂單明細
      INNER JOIN 產品資料 ON 產品資料.產品編號 = 訂單明細.產品編號 WHERE 訂單編號='".$id."'";
      $result = mysqli_query($link, $sql); 
      $row = mysqli_fetch_assoc($result);
      $drink=$row["產品名稱"];
      $price=$row["實際單價"];
      $count=$row["數量"];
?>
<form action="edit_del.php?action=update&id=<?php echo $id ?>"method="post">
<table border="1">
<tr><td><font size="2">產品名稱: </font></td>
   <td><input type="text" name="drink" size="25"
   maxlength="10" value="<?php echo $drink ?>"/></td></tr>
<tr><td><font size="2">實際單價: </font></td>
    <td><input type="text" name="price" size="10"
    maxlength="10" value="<?php echo $price ?>"/></td></tr>
<tr><td><font size="2">數量: </font></td>
   <td><input type="text" name="count" size="10"
    maxlength="10" value="<?php echo $count ?>"/></td></tr>

<tr><td><input type="submit"  value="更新訂單明細"/></td></tr>
</table>
</form>
<?php   
       break;
} 
?>
<form method="post" action="order_digital.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>