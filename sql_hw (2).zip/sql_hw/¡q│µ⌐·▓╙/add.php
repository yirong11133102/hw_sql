<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>add.php</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["Insert"])) {
   $sql_1 = "SELECT MAX(訂單編號) AS max_od_no FROM 訂單明細";
   $result = mysqli_query($link, $sql_1);
   $row = mysqli_fetch_assoc($result);
   $maxODNo = $row['max_od_no'];
   $maxODNo++;
   $newODNo=$maxODNo;

   $drink=$_POST["drink"];
   $count=$_POST["count"];
   $price=$_POST["price"];

   $pd_no="";
   if($drink=="蘋果汁")
      $pd_no=1;
   if($drink=="蔬果汁")
      $pd_no=2;
   if($drink=="汽水")
      $pd_no=3;
   if($drink=="蘆筍汁")
      $pd_no=4;
   if($drink=="運動飲料")
      $pd_no=5;
   if($drink=="牛奶")
      $pd_no=9;
   if($drink=="咖啡")
      $pd_no=10;
   if($drink=="奶茶")
      $pd_no=11;
   if($drink=="啤酒")
      $pd_no=12;
   if($drink=="烏龍茶")
      $pd_no=6;
   if($drink=="紅茶")
      $pd_no=7;

$in = "INSERT INTO 訂單明細 (訂單編號, 產品編號, 實際單價, 數量) VALUES (";
$in .= "'" . $newODNo . "','" . $pd_no . "','".$price . "','" . $count ."')";

mysqli_query($link, 'SET NAMES utf8'); 
if ( mysqli_query($link, $in) )
   echo "資料新增成功<br/>";
else
   die("資料新增失敗<br/>");
}
?>
<form action="add.php" method="post">
<table border="1">
<h2>新增訂單明細資料</h2>
<tr><td>產品名稱:</td>
   <td><select name="drink">
      <option value="蘋果汁" selected="True">蘋果汁	</option>
      <option value="蔬果汁">蔬果汁	</option>
      <option value="汽水">汽水	</option>
      <option value="蘆筍汁">蘆筍汁	</option>
      <option value="運動飲料">	運動飲料	</option>
      <option value="牛奶">牛奶	</option>
      <option value="礦泉水">礦泉水	</option>
      <option value="紅茶">紅茶	</option>
      <option value="烏龍茶">烏龍茶	</option>
      <option value="咖啡">咖啡	</option>
      <option value="奶茶">奶茶	</option>
      <option value="啤酒">啤酒	</option>
   </td></tr>
   <tr><td>數量:</td>
   <td><input type="text" name="count" size="10"/></td></tr>
   <tr><td>實際單價:</td>
   <td><input type="text" name="price" size="10"/></td></tr>
</table>
<p>
<input type="submit" name="Insert" value="新增"/><hr>
<p>&nbsp</p>
</form>
<form method="post" action="order_digital.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>