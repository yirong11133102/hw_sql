<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>edit_del.php</title>
</head>
<body>
<?php
require_once("open.inc");
$id = $_GET["id"];
$action = $_GET["action"];
//所有日期及編號皆無法更改及刪除
switch ($action) {
   case "update": 
      
      $pay=$_POST["付款方式"];
      $get=$_POST["交貨方式"];
   
      $sql = "UPDATE 訂單 SET 付款方式=
      '".$pay."', 交貨方式='".$get."' WHERE 訂單編號='".$id."'";
      mysqli_query($link, $sql);  
      echo "修改完成!";
      break;

   case "del": 
      $sql = "DELETE FROM 訂單 WHERE 訂單編號='".$id."'";
      mysqli_query($link, $sql);
      echo "成功刪除資料!";
      break;
      
   case "edit":
      $sql = "SELECT*FROM 訂單 WHERE 訂單編號='".$id."'";
      $result = mysqli_query($link, $sql); 
      $row = mysqli_fetch_assoc($result);
      $pay=$row["付款方式"];
      $get=$row["交貨方式"];
?>
<form action="edit_del.php?action=update&id=<?php echo $id ?>"method="post">
<table border="1">
<tr><td><font size="2">付款方式: </font></td>
   <td><input type="text" name="付款方式" size="25"
   maxlength="10" value="<?php echo $pay ?>"/></td></tr>
<tr><td><font size="2">交貨方式: </font></td>
    <td><input type="text" name="交貨方式" size="10"
    maxlength="10" value="<?php echo $get ?>"/></td></tr>
<tr><td><input type="submit"  value="更新訂單資料"/></td></tr>
</table>
</form>
<?php   
       break;
} 
?>
<form method="post" action="order.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>