<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>使用者下單</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["order"])) {

    $name = $_POST["姓名"];
    $phone = $_POST["聯絡電話"];
    $class = $_POST["類別名稱"];
    $pay = $_POST["付款方式"];
    $get = $_POST["交貨方式"];
    $date = date("Y-m-d");
    //另外新增文字檔，將使用者下單的資料紀錄在裡面
    $content = "購買者姓名: $name\n聯絡電話: $phone\n產品類別: $class\n付款方式: $pay\n交貨方式: $get\n訂貨日期:$date
    \n
    \n";
    file_put_contents("user_order.txt", $content, FILE_APPEND);
    
    //取資料表中最大值的訂單編號開始遞增
    $sql_1 = "SELECT MAX(訂單編號) AS max_order_no FROM 訂單";
    $result_1 = mysqli_query($link, $sql_1);
    $row = mysqli_fetch_assoc($result_1);
    $maxorderNo = $row['max_order_no'];
    $neworderNo = $maxorderNo + 1;
    
    //員工編號從員工資料表中隨機取得編號
    $sql_2 = "SELECT 員工編號 FROM 員工 ORDER BY RAND() LIMIT 1";
    $result_2 = mysqli_query($link, $sql_2);
    $row_2 = mysqli_fetch_assoc($result_2);
    $employee_id = $row_2['員工編號'];

    //客戶編號從客戶資料表中隨機取得編號
    $sql_3 = "SELECT 客戶編號 FROM 客戶 ORDER BY RAND() LIMIT 1";
    $result_3 = mysqli_query($link, $sql_3);
    $row_3 = mysqli_fetch_assoc($result_3);
    $client_id = $row_3['客戶編號'];

    $orderdate = date("Y-m-d");//下單日期預設當下
    $rd = rand(1,7);
    $rd1 = rand(1,3);
    $rd_hour = rand(0, 23);
    $rd_min = rand(0, 59);
    $rd_sec = rand(0, 59);
    //出貨時間隨機配置
    $time = sprintf("%02d:%02d:%02d", $rd_hour, $rd_min, $rd_sec);
    //出貨日期為下單七天內皆有可能出貨
    $shipdate = date("Y-m-d H:i:s", strtotime($orderdate . " +$rd day".$time));
    //預計到貨日期為出貨後3天
    $ex_arrival = date("Y-m-d H:i:s", strtotime($shipdate . " +3 day"));
    //無法確切知道實際到貨日，先給予空值
    $act_arrival=null;
    
    $in = "INSERT INTO 訂單 (訂單編號, 員工編號, 客戶編號, 訂貨日期, 出貨日期, 預計到貨日期, 實際到貨日期, 付款方式, 交貨方式) VALUES (";
    $in .= "'" . $neworderNo . "','" . $employee_id . "','";
    $in .= $client_id . "','" . $orderdate . "','" . $shipdate . "','" . $ex_arrival . "','";
    $in .= $act_arrival . "','" . $pay . "','" . $get . "')";
 
    mysqli_query($link, $in); 

}
?>
<?php
//以下表單介面以一般使用者下單時的系統介面
?>
<form action="user_order.php" method="post">
<table>
<h2>下單專區</h2>
<tr><td>姓名:</td>
   <td><input type="text" name="姓名" size="12"/></td></tr>
<tr><td>聯絡電話:</td>
   <td><input type="text" name="聯絡電話" size="12"/></td></tr>
<tr><td>購買產品類別:</td>
<td><select name="類別名稱">
      <option value="果汁" selected="True">果汁	</option>
      <option value="茶類">茶類	</option>
      <option value="蘇打類">蘇打類	</option>
      <option value="奶類">奶類	</option>
      <option value="運動飲料">	運動飲料	</option>
      <option value="水類">水類	</option>
      <option value="酒類">酒類	</option>
      <option value="咖啡類">咖啡類	</option>
</td></tr>
<tr><td>交貨方式:</td>
<td><select name="交貨方式">
      <option value="海運" selected="True">海運	</option>
      <option value="空運">空運	</option>
      <option value="郵寄">郵寄	</option>
      <option value="快遞">快遞	</option>
</tr>
<tr><td>付款方式:</td>
<td><select name="付款方式">
      <option value="現金" selected="True">現金	</option>
      <option value="信用卡">信用卡	</option>
      <option value="支票">支票	</option>
   </td></tr><p>
   </table>
<p>
<input type="submit" name="order" value="下單"/><hr>

</form>
<form method="post" action="order.php">
<input type="submit" name="home" value="回首頁"/>
</body>
</html>