<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>add.php</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["Insert"])) {
   $sql_1 = "SELECT MAX(類別編號) AS max_pc_no FROM 產品類別";
   $result = mysqli_query($link, $sql_1);
   $row = mysqli_fetch_assoc($result);
   $maxPcNo = $row['max_pc_no'];
   $newPcNo = $maxPcNo + 1;
   $class=$_POST["類別名稱"];

   $in = "INSERT INTO 產品類別 (類別編號, 類別名稱) VALUES (";
    $in .= "'" . $newPcNo . "','" . $_POST["類別名稱"] ."')";

   mysqli_query($link, 'SET NAMES utf8'); 
   if ( mysqli_query($link, $in) )
      echo "資料新增成功<br/>";
   else
      die("資料新增失敗<br/>");
}


?>
<form action="add.php" method="post">
<table border="1">
<h2>新增產品類別</h2>
<tr>
   <td>類別名稱:</td>
   <td><select name="類別名稱">
      <option value="果汁" selected="True">果汁	</option>
      <option value="茶類">茶類	</option>
      <option value="蘇打類">蘇打類	</option>
      <option value="奶類">奶類	</option>
      <option value="運動飲料">	運動飲料	</option>
      <option value="水類">水類	</option>
      <option value="酒類">酒類	</option>
      <option value="咖啡類">咖啡類	</option>
   </td>
</tr>
</table>
<p>
<input type="submit" name="Insert" value="新增"/><hr>
<p>&nbsp</p>
</form>
<form method="post" action="product_class.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>