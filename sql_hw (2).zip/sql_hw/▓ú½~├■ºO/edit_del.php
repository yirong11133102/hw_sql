<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>revise.php</title>
</head>
<body>
<?php
require_once("open.inc");
$id = $_GET["id"];
$action = $_GET["action"];

switch ($action) {
   case "update": 
      $class=$_POST["類別名稱"];
      $sql = "UPDATE 產品類別 SET 類別名稱='".$class."' WHERE 類別編號='".$id."'";
      mysqli_query($link, $sql); 
      echo "修改完成!";
      break;
   case "del": 
      $sql_del = "SELECT 類別編號 FROM 產品類別 WHERE 類別編號='".$id."'";
      $result_del = mysqli_query($link, $sql_del);
      $row_del = mysqli_fetch_assoc($result_del);
      $deleted_id = $row_del['類別編號'];
      $sql = "DELETE FROM 產品類別 WHERE 類別編號='".$id."'";
      mysqli_query($link, $sql);
      echo "成功刪除資料!";
      $update_sql = "UPDATE 產品類別 SET 類別編號 = 類別編號 - 1 WHERE 類別編號 > '$deleted_id'";
      mysqli_query($link, $update_sql);
      break;
   case "edit":
      $sql = "SELECT * FROM 產品類別 WHERE 類別編號='".$id."'";
      $result = mysqli_query($link, $sql);
      $row = mysqli_fetch_assoc($result);
      $class=$row["類別名稱"];
?>
<form action="edit_del.php?action=update&id=<?php echo $id ?>"method="post">
<table border="1">
<tr><td><font size="2">類別: </font></td>
   <td><input type="text" name="類別名稱" size="25"
   maxlength="10" value="<?php echo $class ?>"/></td></tr>
<tr><td><input type="submit"  value="更新產品類別"/></td></tr>
</table>
</form>
<?php   
       break;
}
?>

<form method="post" action="product_class.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>