<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>product_class.php</title>
</head>
<body>
<h1>功能區</h1>
<table>
<tr>
<form method="post" action="product_class.php">
<td><input type="submit" name="Query" value="查詢"></form></td>
<form method="post" action="add.php">
<td><input type="submit" value="新增資料"></form></td></tr>
</table>
<?php
require_once("open.inc");
if ( isset($_POST["Query"]) ) {
   $sql = "SELECT * FROM 產品類別 ";
   $result = mysqli_query($link, $sql); 
   echo "<br/><table border=1>";
   echo "<tr>";
   while ( $meta = mysqli_fetch_field($result) )
      echo "<td>".$meta->name."</td>";
   echo "<td>功能</td>";
   echo "</tr>";
   $total_fields = mysqli_num_fields($result);
   while ($rows = mysqli_fetch_array($result, MYSQLI_NUM)) {
      echo "<tr>";
      for ( $i = 0; $i < $total_fields; $i++ ){
         echo "<td>".$rows[$i]."</td>";
        }
         echo "<td><a href='edit_del.php?action=edit&id=";
         echo $rows[0]."'><b>編輯</b> | ";
         echo "<a href='edit_del.php?action=del&id=";
         echo $rows[0]."'><b>刪除</b></td>";    
         echo "</tr>"; 
      echo "</tr>";
   }
   echo "</table>";
   $total_records = mysqli_num_rows($result);
   echo "記錄總數: $total_records 筆<br/><br/>";
   mysqli_free_result($result);
 }
?>
<hr><form method="post" action="product_class.php">
<input type="submit" name="home" value="回首頁"/>
</form>
</body>
</html>